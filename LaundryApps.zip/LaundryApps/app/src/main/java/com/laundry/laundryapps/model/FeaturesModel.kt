package com.laundry.laundryapps.model

data class FeaturesModel(
    val name : String,
    val image : Int
)
